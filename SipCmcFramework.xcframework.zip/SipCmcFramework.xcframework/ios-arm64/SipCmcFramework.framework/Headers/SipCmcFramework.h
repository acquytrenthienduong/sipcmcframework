//
//  SipCmcFramework.h
//  SipCmcFramework
//
//  Created by Yobobingo on 12/30/20.
//  Copyright © 2020 Nguyễn Quang. All rights reserved.
//

#import <UIKit/UIkit.h>
#import "AudioHelper.h"

//! Project version number for SipCmcFramework.
FOUNDATION_EXPORT double SipCmcFrameworkVersionNumber;

//! Project version string for SipCmcFramework.
FOUNDATION_EXPORT const unsigned char SipCmcFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SipCmcFramework/PublicHeader.h>


